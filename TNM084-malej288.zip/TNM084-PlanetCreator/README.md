# TNM084-PlanetCreator
Project in the course TNM084, procedural methods for images. Program in Unity that allows the user to create small planets with different noise methods. 
